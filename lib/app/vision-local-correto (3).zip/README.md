# Visão Local - corrigido
Deploy estrutura correta
- app/layout.tsx
- app/page.tsx
- lib/supabase.ts
